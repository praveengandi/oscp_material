# OSCP 
   
Hello world! This repo contain some of the scripts, exploits, and documents made during my OSCP journey. The list include but not limited to the following:

### LinuxPrivCheck.sh
Yes, there are far better scripts out there, However this one has less output to go thru and it has colors. Think basic nmap scan to look for low hanging fruit followed by more complete scan.

### PortKnocker.sh
Basic port knocking script with cool colors

### CronJobChecker.sh
Cron job checker script that may reveal root cron jobs by checking for newly spawned processes! kudos to IppSec

### WinPrivCheck.bat
Comprehensive Windows privesc script that checks KBs as well as common misconfigurations

### SQL Injection Cheatsheet
No SQLMap. No problem. This cheatsheet will walk you thru how to automate things like blind SQL injection with wfuzz


-------------------------------------------------------------------------------------------------------------

I'm always open to suggestions, please let me know if there is anything I can add or improve!
